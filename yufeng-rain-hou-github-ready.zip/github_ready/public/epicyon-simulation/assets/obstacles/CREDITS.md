# Obstacle assets

Traffic cone: Calinou (2015), CC0 1.0 Universal.
Source: https://opengameart.org/content/traffic-cone-0
Download: https://opengameart.org/sites/default/files/cone01.zip
License: https://creativecommons.org/publicdomain/zero/1.0/

The original model.obj (320 triangles) was converted to traffic-cone.stl.
The preview scales it to 143 mm high and uses a simple orange material.
No original textures or executable files are included. The source is OBJ,
not originally STL; conversion preserves its vertex geometry.

The parcel, water bottle and drink can are original primitive-based scene props
defined in obstacles.mjs, with approximate everyday dimensions in millimetres.
