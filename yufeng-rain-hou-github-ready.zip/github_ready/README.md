# Yufeng “Rain” Hou — Engineering Portfolio

A responsive, single-page portfolio for a UBC engineering student working across robotics, automation, design, analysis, and creative technology. The interface uses a technical editorial system, an animated kinematic hand diagram, theme switching, and a Netlify-powered contact form.

## Technology

- TanStack Start and React 19
- TypeScript and Tailwind CSS 4
- Lucide icons
- Netlify Forms

## Local development

Install dependencies with `pnpm install`, then run `pnpm dev`. The site deploys to Netlify with the configuration in `netlify.toml`.

All portfolio copy and repeatable content lives in `src/portfolio-data.ts`. Replace `public/Yufeng_Hou_Resume.pdf` with the final résumé, and replace media placeholders as project imagery becomes available.
